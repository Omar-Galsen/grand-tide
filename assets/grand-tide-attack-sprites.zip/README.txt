Grand Tide attack sprites
32 transparent PNGs, 256x256 pixels.
hero = player; pirate = scouts and captain.
Filename: character_direction_frame.png
Directions: 0 front, 1 back, 2 left, 3 right.
Frames: 0 wind-up, 1 release, 2 strike, 3 recovery.
Mirror direction 2 frame 3 horizontally when rendering.
Feet baseline y=245; use consistent scale for all frames.
